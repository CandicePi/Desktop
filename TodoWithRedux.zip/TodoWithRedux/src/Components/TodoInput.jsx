import React, { use, useState } from 'react'
import { addTodo } from '../redux/slices/todosSlice'
import { useDispatch } from 'react-redux'
import './TodoInput.css'

function TodoInput() {
    const dispatch = useDispatch()
    const [input, setInput] = useState('')

    function handleAdd() {
        dispatch(addTodo(input))
        setInput('')
    }

    return (
        <div className='todo-input-container'>
            <input type="text" placeholder='Add a new task !!!' value={input} onChange={(e) => setInput(e.target.value)}/>
            <button onClick={handleAdd}>➕</button>
        </div>
    )
}

export default TodoInput