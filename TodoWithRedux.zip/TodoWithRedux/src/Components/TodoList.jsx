import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { deleteTodo, toggleTodo, setFilter } from '../redux/slices/todosSlice'
import './TodoList.css'

function TodoList() {
    const dispatch = useDispatch()

    const todos = useSelector((state) => state.items)
    const filter = useSelector((state) => state.filter)


    return (
        <div>
            <div className="filter-container">
                <button style={{background: filter==='all' ? 'red': ''}} onClick={() => dispatch(setFilter('all'))}>All</button>
                <button style={{background: filter==='completed' ? 'red': ''}} onClick={() => dispatch(setFilter('completed'))}>Completed</button>
                <button style={{background: filter==='pending' ? 'red': ''}} onClick={() => dispatch(setFilter('pending'))}>Pending</button>
            </div>
            {filter === 'all' ? (
                <div>
                    {todos.map((e,i) => (
                        <div className="todo-item" key={e.id}>
                            <h2>{e.text}</h2>
                            <p onClick={() => dispatch(deleteTodo(e.id))}>🗑️</p>
                            <div>
                                <input type="checkbox" checked={e.completed} onClick={() => dispatch(toggleTodo(e.id))} /> 
                                <p>{e.completed ? "completed" : "not completed"}</p>
                            </div>
                        </div>
                    ))}
                </div>
            ): null}

            {filter === 'completed' ? (
                <div>
                    {todos
                        .filter(e => e.completed == true)
                        .map((e,i) => (
                            <div className="todo-item" key={i}>
                                <h2>{e.text}</h2>
                                <p onClick={() => dispatch(deleteTodo(e.id))}>🗑️</p>
                                <div>
                                    <input type="checkbox" checked={e.completed} onClick={() => dispatch(toggleTodo(e.id))} /> 
                                    <p>{e.completed ? "completed" : "not completed"}</p>
                                </div>
                            </div>
                        ))
                    }
                </div>
            ): null}

            {filter === 'pending' ? (
                <div>
                    {todos
                        .filter(e => e.completed == false)
                        .map((e,i) => (
                            <div className="todo-item" key={i}>
                                <h2>{e.text}</h2>
                                <p onClick={() => dispatch(deleteTodo(e.id))}>🗑️</p>
                                <div>
                                    <input type="checkbox" checked={e.completed} onClick={() => dispatch(toggleTodo(e.id))} /> 
                                    <p>{e.completed ? "completed" : "not completed"}</p>
                                </div>
                            </div>
                        ))
                    }
                </div>
            ): null}
        </div>
    )
}

export default TodoList