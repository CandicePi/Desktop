import { createSlice } from '@reduxjs/toolkit';
import { act } from 'react';

const todoSlice = createSlice({
    name: "todos",
    initialState: {
        items: [],
        filter: 'all'
    },
    reducers: {
        
        addTodo: (state, action) => {
            state.items.unshift({id: crypto.randomUUID(), text: action.payload, completed: false})
        },
        toggleTodo: (state, action) => {
            const todo = state.items.find(t => t.id == action.payload)
            if(todo) {
                todo.completed = !todo.completed
            }
        },
        deleteTodo : (state, action) => {
            state.items = state.items.filter(t => t.id !== action.payload)
        },
        setFilter: (state, action) => {
            state.filter = action.payload
        }
    }
})

console.log(todoSlice)

export const { addTodo, toggleTodo, deleteTodo, setFilter } = todoSlice.actions;
export default todoSlice.reducer;

