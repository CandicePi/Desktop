import { useState } from 'react'
import './App.css'
import TodoInput from './Components/TodoInput'
import TodoList from './Components/TodoList'

function App() {
  

  return (
    <div className='container'>
     <h1>TODO App</h1>
     <TodoInput/>
     <TodoList/>
    </div>
  )
}

export default App
